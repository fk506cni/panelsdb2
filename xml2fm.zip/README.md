# panelsdb2

F1CDX及びNOPの結果xmlを格納するFMDB

DBその他まとめはxml2fm.zipをダウンロードしてください。

### Readme.docx
readme。COIや、起動PWなど記載していますので一読ください。

### パネル検査xml.pptx
パネル検査のxml構造についてのメモ

### panelsdb2操作メモ.pptx
DB操作のメモ